# weatherapp Informatics project
------------------------------
How to install the venv:
------------------------------

Install venv, command: 

#pip install virtualenv

Various libraries will be asked to be installed, these are listed in the requirements.txt file , use the following command to install them, or install
each manually:

#pip install -r requirements.txt

---------------------------------
Running application
---------------------------------

Activate the venv you just installed, command on windows:

#.\venv\Scripts\activate

Run application by running run.py

#python run.py

Copy the following URL into a browser:

http://127.0.0.1:5000/login

System is now fully active!

--------------------------------
Deactivate venv using;

#deactivate

in cmd or terminal.